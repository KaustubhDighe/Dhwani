package com.example.dhwani

import android.app.ActionBar
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.findNavController
import com.example.dhwani.databinding.FragmentTitleBinding

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [TitleFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class TitleFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var task: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val binding = DataBindingUtil.inflate<FragmentTitleBinding>(inflater, R.layout.fragment_title,container,false)
        binding.recordButton.setOnClickListener {
            task = (0..17).random()
            when (task) {
                0 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_searchFragment)
                1 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_searchFragment)
                2 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_emailFragment)
                3 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_textFragment)
                4 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_textFragment)
                5 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_alarmFragment)
                6 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_alarmFragment)
                7 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_cameraFragment)
                8 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_cameraFragment)
                9 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_mapFragment)
                10 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_mapFragment)
                11 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_musicFragment)
                12 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_musicFragment)
                13 -> phoneCall()
                14 -> phoneCall()
                15 -> view?.findNavController()?.navigate(R.id.action_titleFragment_to_calculatorFragment)
                16 -> instiapp()
                else -> didNotUnderstand()

            }
        }
        return binding.root
    }

    private fun didNotUnderstand() {
        // Add functionality which results in the assistant saying
        // "I didn't Understand That" or "Mujhe Yeh Nahi Samjha"
        TODO("Not yet implemented")
    }

    private fun instiapp() {
        //Add intents here
        TODO("Not yet implemented")
    }

    private fun phoneCall() {
        //Add intents here
        TODO("Not yet implemented")
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment TitleFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            TitleFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}